# CEN-4010-Group-6-Team-Project-Geek-Text
We will be creating an API Service to support an online web application bookstore that targets a particular niche in technology. The application will be named Geek Text.

Contributors:
- Isaac Del Castillo
- Alexander Delgado
- Andy Delgado
- Taylor DeMarzo
- Andy Diaz
